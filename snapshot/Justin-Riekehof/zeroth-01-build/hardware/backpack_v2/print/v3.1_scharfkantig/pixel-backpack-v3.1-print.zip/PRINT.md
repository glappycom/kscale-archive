# Pixel Backpack v3.1 — Druckdateien

Drei Teile, alle bereits in **Druckorientierung** (Z = nach oben auf dem Bett), Millimeter,
Binary-STL, ein Körper je Datei, nicht spiegeln. Passen auf das Bambu Lab P2S-Bett (256 mm).

| Datei | Teil | Bett-Auflage | Größe (mm) | Support |
| --- | --- | --- | --- | --- |
| `pixel-backpack-v3.1_1-base.stl` | Grundrahmen mit LiPo-Schublade | Grundplatte (die Fläche zum Torso) liegt unten, Wände wachsen nach oben | 160 × 152 × 50 | keiner |
| `pixel-backpack-v3.1_2-lid.stl` | Rückdeckel mit Cradles für Schalter, Sicherungshalter, XT60-Paare, Warner | **Außenseite unten**, Rippen wachsen nach oben (2-mm-Lippen an den Rippen sind kurze Überhänge) | 160 × 152 × 19 | keiner |
| `pixel-backpack-v3.1_3-torso-insert.stl` | Pi-Träger für den Torso-Innenraum | steht auf der Unterkante (Platte + Laschen), Standoffs mit 45°-Dach | 72 × 22 × 117 | keiner; Brim empfohlen (5 cm² Auflage bei 117 mm Höhe) |

## Bambu PETG (wie in der Spezifikation)

Düse 240–250 °C, Bett 70–80 °C, 4 Wandlinien, 40 % Gyroid, Support-Z-Abstand 0,2 mm
(nur falls der Slicer doch etwas vorschlägt). Beim Deckel liegen Beschriftungen („30A“, „BAL“,
„5V/GND“) und der versenkte Kragen des Schieberschlitzes auf der Bett-Seite — das sind 0,6 mm
tiefe Vertiefungen in der ersten Lage, kein Problem.

## Nach dem Druck

* Gewindeeinsätze: 4× M3 im Grundrahmen (Ecken, für den Deckel) und 2× M3 in den Laschen des
  Trägers; Torso-Schrauben gehen in die vorhandenen Hülsen des Torsos (4× M3×8).
* Schieberschlitz (Deckel, X −61 / Z 348–369) und Taster-/Displayfenster am realen Modul
  nachmessen und ggf. nacharbeiten — die Lagen sind Annahmen `[S]` (siehe README).
* Reihenfolge: Träger von oben in den Torso (Halsteil ab) → Grundrahmen an den Torso →
  Waveshare, Cutoff, Pololu bestücken → Deckel mit Schalter/Sicherung/XT60/Warner vorbereiten
  → verkabeln → Deckel → LiPo von links einschieben.

Quelle: `../backpack_v3.py` (CadQuery), Kabelprüfung `../check_cables.py`, Details `../README.md`.
